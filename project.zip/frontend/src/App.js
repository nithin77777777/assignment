
import React from 'react';

function App() {
    return (
        <div className="App">
            <h1>Hello, React App!</h1>
        </div>
    );
}

export default App;
