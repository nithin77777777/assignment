
import React from 'react';

function MapView() {
    return (
        <div>
            <h2>Map View Page</h2>
        </div>
    );
}

export default MapView;
